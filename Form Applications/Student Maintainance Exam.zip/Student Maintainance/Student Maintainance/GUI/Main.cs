﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Student_Maintainance.Business;

namespace Student_Maintainance.GUI
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void ButtonSave_Click(object sender, EventArgs e)
        {
            string input = "";
            Student stu = new Student();
            input = textBoxStudentNumber.Text.Trim();
    
            int tempNumber = Convert.ToInt32(textBoxStudentNumber.Text.Trim());
            if (!(stu.IsUniqueStudentNumber(tempNumber)))
            {
                MessageBox.Show("This Student Number already exists!", "Duplicate Student Number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxStudentNumber.Clear();
                textBoxStudentNumber.Focus();
                return;
            }

            input = textBoxFirstName.Text.Trim();

            input = textBoxLastName.Text.Trim();

            input = textBoxPhoneNumber.Text.Trim();

            input = textBoxEmail.Text.Trim();

            stu.StudentNumber = Convert.ToInt32(textBoxStudentNumber.Text.Trim());
            stu.FirstName = textBoxFirstName.Text.Trim();
            stu.LastName = textBoxLastName.Text.Trim();
            stu.PhoneNumber = textBoxPhoneNumber.Text.Trim();
            stu.Email = textBoxEmail.Text.Trim();
            stu.SaveStudent(stu);
            MessageBox.Show("Student record has been saved successfully.", "Student Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void ButtonListAll_Click(object sender, EventArgs e)
        {
            listViewStudents.Items.Clear();
            Student stu = new Student();
            List<Student> listStu = stu.GetStudentList();
            if (listStu != null)
            {
                foreach (Student stuItem in listStu)
                {
                    ListViewItem item = new ListViewItem(stuItem.StudentNumber.ToString());
                    item.SubItems.Add(stuItem.FirstName);
                    item.SubItems.Add(stuItem.LastName);
                    item.SubItems.Add(stuItem.PhoneNumber);
                    item.SubItems.Add(stuItem.Email);
                    listViewStudents.Items.Add(item);
                }
            }
            else
            {
                MessageBox.Show("No Student Data in the database.", "No Student Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void ComboBoxOption_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indexSelected = comboBoxOption.SelectedIndex;
            switch (indexSelected)
            {
                case 1:
                    labelMessage.Text = "Please enter Student Number";
                    textBoxInput.Clear();
                    textBoxInput.Focus();
                    break;
                case 2:
                    labelMessage.Text = "Please enter Last Name";
                    textBoxInput.Clear();
                    textBoxInput.Focus();
                    break;
                default:
                    labelMessage.Text = "";
                    break;
            }
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {

            int selectedIndex = comboBoxOption.SelectedIndex;

            switch (selectedIndex)
            {
                case 1:
                    Student stu = new Student();
                    stu = stu.SearchStudent(Convert.ToInt32(textBoxInput.Text.Trim()));
                    if (stu != null)
                    {
                        textBoxStudentNumber.Text = stu.StudentNumber.ToString();
                        textBoxFirstName.Text = stu.FirstName;
                        textBoxLastName.Text = stu.LastName;
                        textBoxPhoneNumber.Text = stu.PhoneNumber;
                        textBoxEmail.Text = stu.Email;
                    }
                    else
                    {
                        textBoxInput.Clear();
                        textBoxInput.Focus();
                        string error = "Record not found !" + "\n" + "Please enter Student Number again.";
                        MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    break;
                case 2: 
                    Student tempStu2 = new Student();
                    List<Student> listTemp2 = tempStu2.SearchStudent(textBoxInput.Text.Trim());
                    listViewStudents.Items.Clear();
                    if (listTemp2 != null)
                    {
                        foreach (Student anStu in listTemp2)
                        {
                            ListViewItem item = new ListViewItem(anStu.StudentNumber.ToString());
                            item.SubItems.Add(anStu.FirstName);
                            item.SubItems.Add(anStu.LastName);
                            item.SubItems.Add(anStu.PhoneNumber);
                            item.SubItems.Add(anStu.Email);
                            listViewStudents.Items.Add(item);
                        }
                    }
                    else
                    {

                    }
                    break;
                default:
                    break;
            }

        }

        private void Main_Load(object sender, EventArgs e)
        {
            comboBoxOption.SelectedIndex = 0;
        }

        private void ButtonExit_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to exit?";
            const string caption = "EXIT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}

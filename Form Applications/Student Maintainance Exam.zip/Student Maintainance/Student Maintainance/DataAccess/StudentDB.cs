﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Student_Maintainance.Business;

namespace Student_Maintainance.DataAccess
{
    class StudentDB
    {
        public static void SaveRecord(Student stu)
        {
            SqlConnection connDB = UtilityDB.connDB();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connDB;
            cmd.CommandText = "INSERT INTO Students(StudentNumber,FirstName,LastName,PhoneNumber,Email)" +
                                " VALUES (@StudentNumber,@FirstName,@LastName,@PhoneNumber,@Email)";
            cmd.Parameters.AddWithValue("@StudentNumber", stu.StudentNumber);
            cmd.Parameters.AddWithValue("@FirstName", stu.FirstName);
            cmd.Parameters.AddWithValue("@LastName", stu.LastName);
            cmd.Parameters.AddWithValue("@PhoneNumber", stu.PhoneNumber);
            cmd.Parameters.AddWithValue("@Email", stu.Email);
            cmd.ExecuteNonQuery();
            connDB.Close();
        }

        public static bool IsUniqueStudentNumber(int tempNumber)
        {
            SqlConnection connDB = UtilityDB.connDB();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connDB;
            cmd.CommandText = "SELECT * FROM Students " +
                             " WHERE StudentNumber =" + tempNumber;
            int id = Convert.ToInt32(cmd.ExecuteScalar());
            if (id != 0)
            {
                connDB.Close();
                return false;
            }
            connDB.Close();
            return true;
        }

        public static List<Student> GetRecordList()
        {
            List<Student> listStu = new List<Student>();
            SqlConnection connDB = UtilityDB.connDB();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Students", connDB);
            SqlDataReader reader = cmd.ExecuteReader();
            Student stu;

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    stu = new Student();//create the object here, not outside
                    stu.StudentNumber = Convert.ToInt32(reader["StudentNumber"]);
                    stu.FirstName = reader["FirstName"].ToString();
                    stu.LastName = reader["LastName"].ToString();
                    stu.PhoneNumber = reader["PhoneNumber"].ToString();
                    stu.Email = reader["Email"].ToString();
                    listStu.Add(stu);
                }
            }
            else
            {
                listStu = null;
            }

            return listStu;
        }



        public static Student SearchRecord(int searchId)
        {
            Student stu = new Student();
            SqlConnection sqlConn = UtilityDB.connDB();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlConn;
            cmd.CommandText = "SELECT * from Students " +
                                "WHERE StudentNumber = @StudentNumber ";
            cmd.Parameters.AddWithValue("@StudentNumber", searchId);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                stu.StudentNumber = Convert.ToInt32(reader["StudentNumber"]);
                stu.FirstName = reader["FirstName"].ToString();
                stu.LastName = reader["LastName"].ToString();
                stu.PhoneNumber = reader["PhoneNumber"].ToString();
                stu.Email = reader["Email"].ToString();

            }
            else
            {
                stu = null;
            }

            return stu;
        }
   
        public static List<Student> SearchRecord(string input)
        {
            List<Student> listStu = new List<Student>();
            List<Student> listTemp = new List<Student>();
            Student stu = new Student();
            listStu = stu.GetStudentList();
            Student stu2;
            if (listStu != null)
            {
                foreach (Student anStu in listStu)
                {
                    // if (anEmp.FirstName.ToUpper() == input.ToUpper())
                    if ((input.ToUpper() == anStu.FirstName.ToUpper()) || (input.ToUpper() == anStu.LastName.ToUpper()))
                    {
                        stu2 = new Student();
                        stu2.StudentNumber = Convert.ToInt32(anStu.StudentNumber);
                        stu2.FirstName = anStu.FirstName;
                        stu2.LastName = anStu.LastName;
                        stu2.PhoneNumber = anStu.PhoneNumber;
                        stu2.Email = anStu.Email;
                        listTemp.Add(stu2);
                    }
                }

            }
            return listTemp;
        }
    }
}

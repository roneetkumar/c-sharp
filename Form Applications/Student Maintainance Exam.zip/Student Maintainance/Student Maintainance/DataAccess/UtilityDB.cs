﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration; 

namespace Student_Maintainance.DataAccess
{
    class UtilityDB
    {
        public static SqlConnection connDB()
        {
            SqlConnection connDB = new SqlConnection();
            connDB.ConnectionString = ConfigurationManager.ConnectionStrings["StudentDBConnection"].ConnectionString;
            connDB.Open();
            return connDB;
        }

    }
}
